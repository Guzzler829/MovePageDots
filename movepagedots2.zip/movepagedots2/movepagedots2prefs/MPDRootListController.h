#import <Preferences/PSListController.h>

@interface MPDRootListController : PSListController

@end
