#import <UIKit/UIKit.h>
#import <Cephei/HBPreferences.h>

HBPreferences* preferences = nil;

BOOL enabled = YES;

NSString* heightValue = @"0.0";
